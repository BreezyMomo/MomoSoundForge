import { Tabs as TabsPrimitive } from "@base-ui/react/tabs";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/react/lib/utils";

function Tabs({
  className,
  orientation = "horizontal",
  ...props
}: TabsPrimitive.Root.Props) {
  return (
    <TabsPrimitive.Root
      data-slot="tabs"
      data-momo-ui=""
      orientation={orientation}
      className={cn(
        "wb:group/tabs wb:flex wb:min-w-0 wb:gap-2 wb:data-[orientation=horizontal]:flex-col",
        className,
      )}
      {...props}
    />
  );
}

const tabsListVariants = cva(
  "wb:group/tabs-list wb:inline-flex wb:w-fit wb:items-center wb:justify-center wb:rounded-[var(--momo-tabs-radius,8px)] wb:[padding:var(--momo-tabs-padding,3px)] wb:[border:var(--momo-tabs-border,0)] wb:gap-[var(--momo-tabs-gap,4px)] wb:text-muted-foreground wb:group-data-[orientation=horizontal]/tabs:h-8 wb:group-data-[orientation=vertical]/tabs:h-fit wb:group-data-[orientation=vertical]/tabs:flex-col wb:data-[variant=line]:rounded-none",
  {
    variants: {
      variant: {
        default: "wb:[background:var(--momo-tabs-bg,var(--ui-surface))]",
        line: "wb:gap-1 wb:bg-transparent",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
);

function TabsList({
  className,
  variant = "default",
  ...props
}: TabsPrimitive.List.Props & VariantProps<typeof tabsListVariants>) {
  return (
    <TabsPrimitive.List
      data-slot="tabs-list"
      data-variant={variant}
      className={cn(tabsListVariants({ variant }), className)}
      {...props}
    />
  );
}

function TabsTrigger({ className, ...props }: TabsPrimitive.Tab.Props) {
  return (
    <TabsPrimitive.Tab
      data-slot="tabs-trigger"
      className={cn(
        "wb:relative wb:inline-flex wb:h-[calc(100%-1px)] wb:flex-1 wb:items-center wb:justify-center wb:gap-1.5 wb:rounded-[var(--momo-tab-radius,6px)] wb:border wb:border-transparent wb:px-1.5 wb:py-0.5 wb:text-sm wb:font-medium wb:whitespace-nowrap wb:text-foreground/60 wb:transition-all wb:group-data-[orientation=vertical]/tabs:w-full wb:group-data-[orientation=vertical]/tabs:justify-start wb:hover:text-foreground wb:focus-visible:border-ring wb:focus-visible:ring-[3px] wb:focus-visible:ring-ring/50 wb:focus-visible:outline-1 wb:focus-visible:outline-ring wb:disabled:pointer-events-none wb:disabled:opacity-50 wb:has-data-[icon=inline-end]:pr-1 wb:has-data-[icon=inline-start]:pl-1 wb:aria-disabled:pointer-events-none wb:aria-disabled:opacity-50 wb:dark:text-muted-foreground wb:dark:hover:text-foreground wb:group-data-[variant=default]/tabs-list:data-active:shadow-sm wb:group-data-[variant=line]/tabs-list:data-active:shadow-none wb:[&_svg]:pointer-events-none wb:[&_svg]:shrink-0 wb:[&_svg:not([class*=size-])]:size-4",
        "wb:group-data-[variant=line]/tabs-list:bg-transparent wb:group-data-[variant=line]/tabs-list:data-active:bg-transparent wb:dark:group-data-[variant=line]/tabs-list:data-active:border-transparent wb:dark:group-data-[variant=line]/tabs-list:data-active:bg-transparent",
        "wb:data-active:[background:var(--momo-tab-active-bg,var(--ui-surface))] wb:data-active:[color:var(--momo-tab-active-fg,var(--ui-text))] wb:data-active:[box-shadow:var(--momo-tab-active-shadow,none)] wb:data-active:[border-color:var(--momo-tab-active-border,transparent)] ",
        "wb:after:absolute wb:after:bg-foreground wb:after:opacity-0 wb:after:transition-opacity wb:group-data-[orientation=horizontal]/tabs:after:inset-x-0 wb:group-data-[orientation=horizontal]/tabs:after:bottom-[-5px] wb:group-data-[orientation=horizontal]/tabs:after:h-0.5 wb:group-data-[orientation=vertical]/tabs:after:inset-y-0 wb:group-data-[orientation=vertical]/tabs:after:-right-1 wb:group-data-[orientation=vertical]/tabs:after:w-0.5 wb:group-data-[variant=line]/tabs-list:data-active:after:opacity-100",
        className,
      )}
      {...props}
    />
  );
}

function TabsContent({ className, ...props }: TabsPrimitive.Panel.Props) {
  return (
    <TabsPrimitive.Panel
      data-slot="tabs-content"
      className={cn("wb:flex-1 wb:text-sm wb:outline-none", className)}
      {...props}
    />
  );
}

export { Tabs, TabsList, TabsTrigger, TabsContent, tabsListVariants };
