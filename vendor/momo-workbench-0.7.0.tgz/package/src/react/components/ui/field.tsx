"use client";

import { useMemo } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/react/lib/utils";

import { Label } from "@/react/components/ui/label";
import { Separator } from "@/react/components/ui/separator";

function FieldSet({ className, ...props }: React.ComponentProps<"fieldset">) {
  return (
    <fieldset
      data-slot="field-set"
      className={cn(
        "wb:flex wb:flex-col wb:gap-4 wb:has-[>[data-slot=checkbox-group]]:gap-3 wb:has-[>[data-slot=radio-group]]:gap-3",
        className,
      )}
      {...props}
    />
  );
}

function FieldLegend({
  className,
  variant = "legend",
  ...props
}: React.ComponentProps<"legend"> & { variant?: "legend" | "label" }) {
  return (
    <legend
      data-slot="field-legend"
      data-variant={variant}
      className={cn(
        "wb:mb-1.5 wb:font-medium wb:data-[variant=label]:text-sm wb:data-[variant=legend]:text-base",
        className,
      )}
      {...props}
    />
  );
}

function FieldGroup({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="field-group"
      className={cn(
        "wb:group/field-group wb:@container/field-group wb:flex wb:w-full wb:flex-col wb:gap-5 wb:data-[slot=checkbox-group]:gap-3 wb:*:data-[slot=field-group]:gap-4",
        className,
      )}
      {...props}
    />
  );
}

const fieldVariants = cva(
  "wb:group/field wb:flex wb:w-full wb:gap-2 wb:data-[invalid=true]:text-destructive",
  {
    variants: {
      orientation: {
        vertical: "wb:flex-col wb:*:w-full wb:[&>.sr-only]:w-auto",
        horizontal:
          "wb:flex-row wb:items-center wb:has-[>[data-slot=field-content]]:items-start wb:*:data-[slot=field-label]:flex-auto wb:has-[>[data-slot=field-content]]:[&>[role=checkbox],[role=radio]]:mt-px",
        responsive:
          "wb:flex-col wb:*:w-full wb:@md/field-group:flex-row wb:@md/field-group:items-center wb:@md/field-group:*:w-auto wb:@md/field-group:has-[>[data-slot=field-content]]:items-start wb:@md/field-group:*:data-[slot=field-label]:flex-auto wb:[&>.sr-only]:w-auto wb:@md/field-group:has-[>[data-slot=field-content]]:[&>[role=checkbox],[role=radio]]:mt-px",
      },
    },
    defaultVariants: {
      orientation: "vertical",
    },
  },
);

function Field({
  className,
  orientation = "vertical",
  ...props
}: React.ComponentProps<"div"> & VariantProps<typeof fieldVariants>) {
  return (
    <div
      role="group"
      data-slot="field"
      data-orientation={orientation}
      className={cn(fieldVariants({ orientation }), className)}
      {...props}
    />
  );
}

function FieldContent({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="field-content"
      className={cn(
        "wb:group/field-content wb:flex wb:flex-1 wb:flex-col wb:gap-0.5 wb:leading-snug",
        className,
      )}
      {...props}
    />
  );
}

function FieldLabel({
  className,
  ...props
}: React.ComponentProps<typeof Label>) {
  return (
    <Label
      data-slot="field-label"
      className={cn(
        "wb:group/field-label wb:peer/field-label wb:flex wb:w-fit wb:gap-2 wb:leading-snug wb:group-data-[disabled=true]/field:opacity-50 wb:has-data-checked:border-primary/30 wb:has-data-checked:bg-primary/5 wb:has-[>[data-slot=field]]:rounded-lg wb:has-[>[data-slot=field]]:border wb:has-[>[data-slot=field]]:not-has-[:disabled,[data-disabled]]:hover:bg-muted/50 wb:has-[>[data-slot=field]]:has-[:focus-visible]:border-ring wb:has-[>[data-slot=field]]:has-[:focus-visible]:ring-3 wb:has-[>[data-slot=field]]:has-[:focus-visible]:ring-ring/50 wb:*:data-[slot=field]:p-2.5 wb:dark:has-data-checked:border-primary/20 wb:dark:has-data-checked:bg-primary/10",
        "wb:has-[>[data-slot=field]]:w-full wb:has-[>[data-slot=field]]:flex-col",
        className,
      )}
      {...props}
    />
  );
}

function FieldTitle({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="field-label"
      className={cn(
        "wb:flex wb:w-fit wb:items-center wb:gap-2 wb:text-sm wb:font-medium wb:group-data-[disabled=true]/field:opacity-50",
        className,
      )}
      {...props}
    />
  );
}

function FieldDescription({ className, ...props }: React.ComponentProps<"p">) {
  return (
    <p
      data-slot="field-description"
      className={cn(
        "wb:text-left wb:text-sm wb:leading-normal wb:font-normal wb:text-muted-foreground wb:group-has-data-horizontal/field:text-balance wb:[[data-variant=legend]+&]:-mt-1.5",
        "wb:last:mt-0 wb:nth-last-2:-mt-1",
        "wb:[&>a]:underline wb:[&>a]:underline-offset-4 wb:[&>a:hover]:text-primary",
        className,
      )}
      {...props}
    />
  );
}

function FieldSeparator({
  children,
  className,
  ...props
}: React.ComponentProps<"div"> & {
  children?: React.ReactNode;
}) {
  return (
    <div
      data-slot="field-separator"
      data-content={!!children}
      className={cn(
        "wb:relative wb:-my-2 wb:h-5 wb:text-sm wb:group-data-[variant=outline]/field-group:-mb-2",
        className,
      )}
      {...props}
    >
      <Separator className="wb:absolute wb:inset-0 wb:top-1/2" />
      {children && (
        <span
          className="wb:relative wb:mx-auto wb:block wb:w-fit wb:bg-background wb:px-2 wb:text-muted-foreground"
          data-slot="field-separator-content"
        >
          {children}
        </span>
      )}
    </div>
  );
}

function FieldError({
  className,
  children,
  errors,
  ...props
}: React.ComponentProps<"div"> & {
  errors?: Array<{ message?: string } | undefined>;
}) {
  const content = useMemo(() => {
    if (children) {
      return children;
    }

    if (!errors?.length) {
      return null;
    }

    const uniqueErrors = [
      ...new Map(errors.map((error) => [error?.message, error])).values(),
    ];

    if (uniqueErrors?.length == 1) {
      return uniqueErrors[0]?.message;
    }

    return (
      <ul className="wb:ml-4 wb:flex wb:list-disc wb:flex-col wb:gap-1">
        {uniqueErrors.map(
          (error, index) =>
            error?.message && <li key={index}>{error.message}</li>,
        )}
      </ul>
    );
  }, [children, errors]);

  if (!content) {
    return null;
  }

  return (
    <div
      role="alert"
      data-slot="field-error"
      className={cn("wb:text-sm wb:font-normal wb:text-destructive", className)}
      {...props}
    >
      {content}
    </div>
  );
}

export {
  Field,
  FieldLabel,
  FieldDescription,
  FieldError,
  FieldGroup,
  FieldLegend,
  FieldSeparator,
  FieldSet,
  FieldContent,
  FieldTitle,
};
