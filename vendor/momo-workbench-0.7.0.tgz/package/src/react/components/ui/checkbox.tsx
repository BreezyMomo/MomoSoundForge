import { Checkbox as CheckboxPrimitive } from "@base-ui/react/checkbox";
import { cn } from "@/react/lib/utils";
import { CheckIcon } from "lucide-react";

function Checkbox({ className, ...props }: CheckboxPrimitive.Root.Props) {
  return (
    <CheckboxPrimitive.Root
      data-slot="checkbox"
      data-momo-ui=""
      className={cn(
        "wb:peer wb:relative wb:flex wb:size-4 wb:shrink-0 wb:items-center wb:justify-center wb:rounded-[4px] wb:border wb:border-input wb:transition-colors wb:outline-none wb:group-has-disabled/field:opacity-50 wb:group-has-[:focus-visible]/field-label:ring-0 wb:group-has-[:focus-visible]/field-label:not-data-checked:border-input wb:after:absolute wb:after:-inset-x-3 wb:after:-inset-y-2 wb:focus-visible:border-ring wb:focus-visible:ring-3 wb:focus-visible:ring-ring/50 wb:disabled:cursor-not-allowed wb:disabled:opacity-50 wb:aria-invalid:border-destructive wb:aria-invalid:ring-3 wb:aria-invalid:ring-destructive/20 wb:aria-invalid:aria-checked:border-primary wb:dark:bg-input/30 wb:dark:aria-invalid:border-destructive/50 wb:dark:aria-invalid:ring-destructive/40 wb:data-checked:border-primary wb:data-checked:bg-primary wb:data-checked:text-primary-foreground wb:group-has-[:focus-visible]/field-label:data-checked:border-primary wb:dark:data-checked:bg-primary",
        className,
      )}
      {...props}
    >
      <CheckboxPrimitive.Indicator
        data-slot="checkbox-indicator"
        className="wb:grid wb:place-content-center wb:text-current wb:transition-none wb:[&>svg]:size-3.5"
      >
        <CheckIcon />
      </CheckboxPrimitive.Indicator>
    </CheckboxPrimitive.Root>
  );
}

export { Checkbox };
