import { useState } from "react";
import { createRoot } from "react-dom/client";
import { ChevronDown } from "lucide-react";
import { Button } from "./components/ui/button";
import { Input } from "./components/ui/input";
import { Checkbox } from "./components/ui/checkbox";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "./components/ui/popover";
import {
  Field,
  FieldGroup,
  FieldLabel,
  FieldDescription,
} from "./components/ui/field";
import { WorkbenchChoice } from "./preferences";
import { useMessages, WorkbenchProvider } from "./context";
import type { DockMenuOptions, DockMenuState } from "../dock-workspace.js";
import type { AppearanceController } from "../appearance.js";
import type { LanguageController } from "../i18n.js";
type ReactDockMenuOptions = DockMenuOptions & {
  appearance?: AppearanceController;
  language?: LanguageController;
};

function DockMenu({
  options,
  state,
}: {
  options: DockMenuOptions;
  state: DockMenuState;
}) {
  const { text, format } = useMessages(options.ui),
    [open, setOpen] = useState(false),
    [name, setName] = useState(""),
    [selected, setSelected] = useState("");
  const saved = state.named.some((item) => item.name === selected)
    ? selected
    : (state.named[0]?.name ?? "");
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger
        id={options.id}
        render={<Button data-momo-ui="" variant="outline" />}
      >
        {text("menu.layout")}
        <ChevronDown data-icon="inline-end" />
      </PopoverTrigger>
      <PopoverContent
        align="end"
        className="wb:w-[min(340px,calc(100vw-2rem))] wb:max-h-[calc(100dvh-2rem)] wb:overflow-y-auto"
      >
        <FieldGroup className="wb:gap-4">
          <FieldDescription>
            {text("layout.dragPanelTabsToDockAltDragToFloat")}
          </FieldDescription>
          <div className="wb:grid wb:grid-cols-2 wb:gap-2">
            {options.presets.map((preset) => (
              <Button
                key={preset.id}
                variant="outline"
                onClick={() => {
                  options.preset(preset.id);
                  setOpen(false);
                }}
              >
                {text(preset.title)}
              </Button>
            ))}
          </div>
          <div className="wb:grid wb:grid-cols-2 wb:gap-2">
            {options.panels.map((panel) => (
              <Field key={panel.id} orientation="horizontal">
                <Checkbox
                  id={options.id + "-" + panel.id}
                  aria-label={format("layout.showPanel", text(panel.title))}
                  checked={state.visible.includes(panel.id)}
                  onCheckedChange={(checked) =>
                    options.toggle(panel.id, checked)
                  }
                />
                <FieldLabel htmlFor={options.id + "-" + panel.id}>
                  {text(panel.title)}
                </FieldLabel>
              </Field>
            ))}
          </div>
          <form
            onSubmit={(event) => {
              event.preventDefault();
              options.save(name);
              setSelected(name.trim());
            }}
          >
            <Field>
              <FieldLabel htmlFor={options.id + "-name"}>
                {text("layout.layoutName")}
              </FieldLabel>
              <Input
                id={options.id + "-name"}
                value={name}
                maxLength={32}
                placeholder={text("layout.eGMyTwoColumnLayout")}
                onChange={(event) => setName(event.target.value)}
              />
              <Button variant="outline" type="submit">
                {text("layout.saveCurrentLayout")}
              </Button>
            </Field>
          </form>
          <Field>
            <FieldLabel>{text("layout.savedLayouts")}</FieldLabel>
            <WorkbenchChoice
              label={text("layout.savedLayouts")}
              value={saved}
              disabled={!state.named.length}
              items={
                state.named.length
                  ? state.named.map((item) => ({
                      value: item.name,
                      label: item.name,
                    }))
                  : [{ value: "", label: text("layout.noSavedLayouts") }]
              }
              onValueChange={setSelected}
            />
            <div className="wb:flex wb:gap-2">
              <Button
                variant="outline"
                disabled={!saved}
                onClick={() => options.load(saved)}
              >
                {text("layout.applyLayout")}
              </Button>
              <Button
                variant="ghost"
                disabled={!saved}
                onClick={() => options.remove(saved)}
              >
                {text("layout.deleteSavedLayout")}
              </Button>
            </div>
          </Field>
          <p className="wb:text-xs wb:text-muted-foreground" role="status">
            {state.status === "layout.layoutSaved"
              ? text(state.status) + String(state.values?.[0] ?? "")
              : state.status
                ? format(state.status, ...(state.values ?? []))
                : text(
                    "layout.layoutIsSavedInThisBrowserSeparatelyFromTheCanvasProject",
                  )}
          </p>
        </FieldGroup>
      </PopoverContent>
    </Popover>
  );
}
export function mountDockMenu(options: ReactDockMenuOptions) {
  const element = options.host.ownerDocument.createElement("div");
  element.style.display = "contents";
  options.host.append(element);
  const root = createRoot(element);
  let disposed = false;
  return {
    update(state: DockMenuState) {
      if (disposed) return;
      const view = <DockMenu options={options} state={state} />;
      root.render(
        options.appearance && options.language ? (
          <WorkbenchProvider
            appearance={options.appearance}
            language={options.language}
            ui={options.ui}
          >
            {view}
          </WorkbenchProvider>
        ) : (
          view
        ),
      );
    },
    dispose() {
      if (disposed) return;
      disposed = true;
      queueMicrotask(() => {
        root.unmount();
        element.remove();
      });
    },
  };
}
