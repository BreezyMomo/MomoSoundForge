import { Slider as SliderPrimitive } from "@base-ui/react/slider";
import { cn } from "@/react/lib/utils";

function Slider({
  className,
  defaultValue,
  value,
  min = 0,
  max = 100,
  getAriaLabel,
  ...props
}: SliderPrimitive.Root.Props & {
  getAriaLabel?: SliderPrimitive.Thumb.Props["getAriaLabel"];
}) {
  const _values = Array.isArray(value)
    ? value
    : Array.isArray(defaultValue)
      ? defaultValue
      : [min, max];

  return (
    <SliderPrimitive.Root
      className={cn(
        "wb:data-[orientation=horizontal]:w-full wb:data-[orientation=vertical]:h-full",
        className,
      )}
      data-slot="slider"
      data-momo-ui=""
      defaultValue={defaultValue}
      value={value}
      min={min}
      max={max}
      thumbAlignment="edge"
      {...props}
    >
      <SliderPrimitive.Control
        data-slot="slider-control"
        className="wb:relative wb:flex wb:h-8 wb:w-full wb:touch-none wb:items-center wb:select-none wb:data-disabled:opacity-50 wb:data-[orientation=vertical]:h-full wb:data-[orientation=vertical]:min-h-40 wb:data-[orientation=vertical]:w-auto wb:data-[orientation=vertical]:flex-col"
      >
        <SliderPrimitive.Track
          data-slot="slider-track"
          className="wb:relative wb:grow wb:overflow-hidden wb:rounded-full wb:bg-muted wb:select-none wb:data-[orientation=horizontal]:h-1 wb:data-[orientation=horizontal]:w-full wb:data-[orientation=vertical]:h-full wb:data-[orientation=vertical]:w-1"
        >
          <SliderPrimitive.Indicator
            data-slot="slider-range"
            className="wb:bg-[var(--ui-control,var(--ui-accent-text))] wb:select-none wb:data-[orientation=horizontal]:h-full wb:data-[orientation=vertical]:w-full"
          />
        </SliderPrimitive.Track>
        {Array.from({ length: _values.length }, (_, index) => (
          <SliderPrimitive.Thumb
            data-slot="slider-thumb"
            key={index}
            index={index}
            getAriaLabel={getAriaLabel ?? (() => props["aria-label"] ?? "")}
            className="wb:relative wb:block wb:size-3 wb:shrink-0 wb:rounded-full wb:border wb:border-[var(--ui-control,var(--ui-accent-text))] wb:bg-background wb:ring-ring/50 wb:transition-[color,box-shadow] wb:select-none wb:after:absolute wb:after:-inset-2 wb:hover:ring-3 wb:focus-visible:ring-3 wb:focus-visible:outline-hidden wb:active:ring-3 wb:disabled:pointer-events-none wb:disabled:opacity-50"
          />
        ))}
      </SliderPrimitive.Control>
    </SliderPrimitive.Root>
  );
}

export { Slider };
