import { useThemedSurface } from "@/react/context";
import * as React from "react";
import { Menu as MenuPrimitive } from "@base-ui/react/menu";
import { cn } from "@/react/lib/utils";
import { ChevronRightIcon, CheckIcon } from "lucide-react";

function DropdownMenu({ ...props }: MenuPrimitive.Root.Props) {
  return <MenuPrimitive.Root data-slot="dropdown-menu" {...props} />;
}

function DropdownMenuPortal({ ...props }: MenuPrimitive.Portal.Props) {
  return <MenuPrimitive.Portal data-slot="dropdown-menu-portal" {...props} />;
}

function DropdownMenuTrigger({ ...props }: MenuPrimitive.Trigger.Props) {
  return <MenuPrimitive.Trigger data-slot="dropdown-menu-trigger" {...props} />;
}

function DropdownMenuContent({
  ref,
  align = "start",
  alignOffset = 0,
  side = "bottom",
  sideOffset = 4,
  className,
  ...props
}: MenuPrimitive.Popup.Props &
  Pick<
    MenuPrimitive.Positioner.Props,
    "align" | "alignOffset" | "side" | "sideOffset"
  >) {
  const surface = useThemedSurface(ref);
  return (
    <MenuPrimitive.Portal>
      <MenuPrimitive.Positioner
        className="wb:isolate wb:z-50 wb:outline-none"
        align={align}
        alignOffset={alignOffset}
        side={side}
        sideOffset={sideOffset}
      >
        <MenuPrimitive.Popup
          data-slot="dropdown-menu-content"
          data-momo-ui=""
          ref={surface}
          className={cn(
            "wb:z-50 wb:max-h-(--available-height) wb:w-(--anchor-width) wb:min-w-32 wb:origin-(--transform-origin) wb:overflow-x-hidden wb:overflow-y-auto wb:rounded-lg wb:bg-popover wb:p-1 wb:text-popover-foreground wb:shadow-md wb:ring-1 wb:ring-foreground/10 wb:duration-100 wb:outline-none wb:data-[side=bottom]:slide-in-from-top-2 wb:data-[side=inline-end]:slide-in-from-left-2 wb:data-[side=inline-start]:slide-in-from-right-2 wb:data-[side=left]:slide-in-from-right-2 wb:data-[side=right]:slide-in-from-left-2 wb:data-[side=top]:slide-in-from-bottom-2 wb:data-open:animate-in wb:data-open:fade-in-0 wb:data-open:zoom-in-95 wb:data-closed:animate-out wb:data-closed:overflow-hidden wb:data-closed:fade-out-0 wb:data-closed:zoom-out-95",
            className,
          )}
          {...props}
        />
      </MenuPrimitive.Positioner>
    </MenuPrimitive.Portal>
  );
}

function DropdownMenuGroup({ ...props }: MenuPrimitive.Group.Props) {
  return <MenuPrimitive.Group data-slot="dropdown-menu-group" {...props} />;
}

function DropdownMenuLabel({
  className,
  inset,
  ...props
}: MenuPrimitive.GroupLabel.Props & {
  inset?: boolean;
}) {
  return (
    <MenuPrimitive.GroupLabel
      data-slot="dropdown-menu-label"
      data-inset={inset}
      className={cn(
        "wb:px-1.5 wb:py-1 wb:text-xs wb:font-medium wb:text-muted-foreground wb:data-inset:pl-7",
        className,
      )}
      {...props}
    />
  );
}

function DropdownMenuItem({
  className,
  inset,
  variant = "default",
  ...props
}: MenuPrimitive.Item.Props & {
  inset?: boolean;
  variant?: "default" | "destructive";
}) {
  return (
    <MenuPrimitive.Item
      data-slot="dropdown-menu-item"
      data-inset={inset}
      data-variant={variant}
      className={cn(
        "wb:group/dropdown-menu-item wb:relative wb:flex wb:cursor-default wb:items-center wb:gap-1.5 wb:rounded-md wb:px-1.5 wb:py-1 wb:text-sm wb:outline-hidden wb:select-none wb:focus:bg-accent wb:focus:text-accent-foreground wb:not-data-[variant=destructive]:focus:**:text-accent-foreground wb:data-inset:pl-7 wb:data-[variant=destructive]:text-destructive wb:data-[variant=destructive]:focus:bg-destructive/10 wb:data-[variant=destructive]:focus:text-destructive wb:dark:data-[variant=destructive]:focus:bg-destructive/20 wb:data-disabled:pointer-events-none wb:data-disabled:opacity-50 wb:[&_svg]:pointer-events-none wb:[&_svg]:shrink-0 wb:[&_svg:not([class*=size-])]:size-4 wb:data-[variant=destructive]:*:[svg]:text-destructive",
        className,
      )}
      {...props}
    />
  );
}

function DropdownMenuSub({ ...props }: MenuPrimitive.SubmenuRoot.Props) {
  return <MenuPrimitive.SubmenuRoot data-slot="dropdown-menu-sub" {...props} />;
}

function DropdownMenuSubTrigger({
  className,
  inset,
  children,
  ...props
}: MenuPrimitive.SubmenuTrigger.Props & {
  inset?: boolean;
}) {
  return (
    <MenuPrimitive.SubmenuTrigger
      data-slot="dropdown-menu-sub-trigger"
      data-inset={inset}
      className={cn(
        "wb:flex wb:cursor-default wb:items-center wb:gap-1.5 wb:rounded-md wb:px-1.5 wb:py-1 wb:text-sm wb:outline-hidden wb:select-none wb:focus:bg-accent wb:focus:text-accent-foreground wb:not-data-[variant=destructive]:focus:**:text-accent-foreground wb:data-inset:pl-7 wb:data-popup-open:bg-accent wb:data-popup-open:text-accent-foreground wb:data-open:bg-accent wb:data-open:text-accent-foreground wb:[&_svg]:pointer-events-none wb:[&_svg]:shrink-0 wb:[&_svg:not([class*=size-])]:size-4",
        className,
      )}
      {...props}
    >
      {children}
      <ChevronRightIcon className="wb:ml-auto" />
    </MenuPrimitive.SubmenuTrigger>
  );
}

function DropdownMenuSubContent({
  align = "start",
  alignOffset = -3,
  side = "right",
  sideOffset = 0,
  className,
  ...props
}: React.ComponentProps<typeof DropdownMenuContent>) {
  return (
    <DropdownMenuContent
      data-slot="dropdown-menu-sub-content"
      className={cn(
        "wb:w-auto wb:min-w-[96px] wb:rounded-lg wb:bg-popover wb:p-1 wb:text-popover-foreground wb:shadow-lg wb:ring-1 wb:ring-foreground/10 wb:duration-100 wb:data-[side=bottom]:slide-in-from-top-2 wb:data-[side=left]:slide-in-from-right-2 wb:data-[side=right]:slide-in-from-left-2 wb:data-[side=top]:slide-in-from-bottom-2 wb:data-open:animate-in wb:data-open:fade-in-0 wb:data-open:zoom-in-95 wb:data-closed:animate-out wb:data-closed:fade-out-0 wb:data-closed:zoom-out-95",
        className,
      )}
      align={align}
      alignOffset={alignOffset}
      side={side}
      sideOffset={sideOffset}
      {...props}
    />
  );
}

function DropdownMenuCheckboxItem({
  className,
  children,
  checked,
  inset,
  ...props
}: MenuPrimitive.CheckboxItem.Props & {
  inset?: boolean;
}) {
  return (
    <MenuPrimitive.CheckboxItem
      data-slot="dropdown-menu-checkbox-item"
      data-inset={inset}
      className={cn(
        "wb:relative wb:flex wb:cursor-default wb:items-center wb:gap-1.5 wb:rounded-md wb:py-1 wb:pr-8 wb:pl-1.5 wb:text-sm wb:outline-hidden wb:select-none wb:focus:bg-accent wb:focus:text-accent-foreground wb:focus:**:text-accent-foreground wb:data-inset:pl-7 wb:data-disabled:pointer-events-none wb:data-disabled:opacity-50 wb:[&_svg]:pointer-events-none wb:[&_svg]:shrink-0 wb:[&_svg:not([class*=size-])]:size-4",
        className,
      )}
      checked={checked}
      {...props}
    >
      <span
        className="wb:pointer-events-none wb:absolute wb:right-2 wb:flex wb:items-center wb:justify-center"
        data-slot="dropdown-menu-checkbox-item-indicator"
      >
        <MenuPrimitive.CheckboxItemIndicator>
          <CheckIcon />
        </MenuPrimitive.CheckboxItemIndicator>
      </span>
      {children}
    </MenuPrimitive.CheckboxItem>
  );
}

function DropdownMenuRadioGroup({ ...props }: MenuPrimitive.RadioGroup.Props) {
  return (
    <MenuPrimitive.RadioGroup
      data-slot="dropdown-menu-radio-group"
      {...props}
    />
  );
}

function DropdownMenuRadioItem({
  className,
  children,
  inset,
  ...props
}: MenuPrimitive.RadioItem.Props & {
  inset?: boolean;
}) {
  return (
    <MenuPrimitive.RadioItem
      data-slot="dropdown-menu-radio-item"
      data-inset={inset}
      className={cn(
        "wb:relative wb:flex wb:cursor-default wb:items-center wb:gap-1.5 wb:rounded-md wb:py-1 wb:pr-8 wb:pl-1.5 wb:text-sm wb:outline-hidden wb:select-none wb:focus:bg-accent wb:focus:text-accent-foreground wb:focus:**:text-accent-foreground wb:data-inset:pl-7 wb:data-disabled:pointer-events-none wb:data-disabled:opacity-50 wb:[&_svg]:pointer-events-none wb:[&_svg]:shrink-0 wb:[&_svg:not([class*=size-])]:size-4",
        className,
      )}
      {...props}
    >
      <span
        className="wb:pointer-events-none wb:absolute wb:right-2 wb:flex wb:items-center wb:justify-center"
        data-slot="dropdown-menu-radio-item-indicator"
      >
        <MenuPrimitive.RadioItemIndicator>
          <CheckIcon />
        </MenuPrimitive.RadioItemIndicator>
      </span>
      {children}
    </MenuPrimitive.RadioItem>
  );
}

function DropdownMenuSeparator({
  className,
  ...props
}: MenuPrimitive.Separator.Props) {
  return (
    <MenuPrimitive.Separator
      data-slot="dropdown-menu-separator"
      className={cn("wb:-mx-1 wb:my-1 wb:h-px wb:bg-border", className)}
      {...props}
    />
  );
}

function DropdownMenuShortcut({
  className,
  ...props
}: React.ComponentProps<"span">) {
  return (
    <span
      data-slot="dropdown-menu-shortcut"
      className={cn(
        "wb:ml-auto wb:text-xs wb:tracking-widest wb:text-muted-foreground wb:group-focus/dropdown-menu-item:text-accent-foreground",
        className,
      )}
      {...props}
    />
  );
}

export {
  DropdownMenu,
  DropdownMenuPortal,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuLabel,
  DropdownMenuItem,
  DropdownMenuCheckboxItem,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
};
