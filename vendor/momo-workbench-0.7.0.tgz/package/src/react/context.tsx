import {
  createContext,
  useContext,
  useEffect,
  useLayoutEffect,
  useState,
  useCallback,
  type ReactNode,
  type Ref,
} from "react";
import type {
  AppearanceController,
  AppearancePreferences,
} from "../appearance.js";
import type { LanguageController } from "../i18n.js";
import { WORKBENCH_CATALOGS } from "../locales.js";

export type WorkbenchMessages = {
  text?: (key: string) => string;
  format?: (key: string, ...values: unknown[]) => string;
  onLanguageChange?: (listener: () => void) => () => void;
};
type ContextValue = {
  appearance: AppearanceController;
  language: LanguageController;
  ui?: WorkbenchMessages;
};
const Context = createContext<ContextValue | null>(null);
export function WorkbenchProvider({
  children,
  ...value
}: ContextValue & { children: ReactNode }) {
  return <Context.Provider value={value}>{children}</Context.Provider>;
}
export function useWorkbench() {
  const value = useContext(Context);
  if (!value) throw Error("WorkbenchProvider is required");
  return value;
}
export function useAppearancePreferences(appearance: AppearanceController) {
  const [value, setValue] = useState<AppearancePreferences>(() =>
    appearance.get(),
  );
  useLayoutEffect(() => {
    setValue(appearance.get());
    return appearance.subscribe(setValue);
  }, [appearance]);
  return value;
}
export function useMessages(provided?: WorkbenchMessages) {
  const context = useContext(Context),
    ui = provided ?? context?.ui;
  const [, refresh] = useState(0);
  useEffect(
    () =>
      ui?.onLanguageChange?.(() => refresh((value) => value + 1)) ??
      context?.language.onLanguageChange(() => refresh((value) => value + 1)),
    [ui, context?.language],
  );
  const language = context?.language.interfaceLanguage() ?? "zh-CN";
  const text = (key: string) =>
    ui?.text?.(key) ??
    WORKBENCH_CATALOGS[language === "en" ? "en" : "zh-CN"][key] ??
    key;
  const format = (key: string, ...values: unknown[]) =>
    ui?.format?.(key, ...values) ??
    text(key).replace(/\{(\d+)\}/g, (_, i) => String(values[Number(i)] ?? ""));
  return { text, format };
}
// Portals receive their provider's full theme, including when two Workbenches coexist.
export function useThemedSurface<T extends HTMLElement>(forwarded?: Ref<T>) {
  const context = useContext(Context),
    [element, setElement] = useState<T | null>(null);
  const ref = useCallback(
    (node: T | null) => {
      setElement(node);
      if (typeof forwarded === "function") forwarded(node);
      else if (forwarded) forwarded.current = node;
    },
    [forwarded],
  );
  useLayoutEffect(() => {
    if (!element || !context) return;
    return context.appearance.attach(element);
  }, [element, context?.appearance]);
  return ref;
}
