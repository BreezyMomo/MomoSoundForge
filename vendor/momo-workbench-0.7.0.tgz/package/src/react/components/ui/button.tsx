import { Button as ButtonPrimitive } from "@base-ui/react/button";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/react/lib/utils";

const buttonVariants = cva(
  "wb:group/button wb:inline-flex wb:shrink-0 wb:items-center wb:justify-center wb:rounded-lg wb:border wb:border-transparent wb:bg-clip-padding wb:text-sm wb:font-medium wb:whitespace-nowrap wb:transition-all wb:outline-none wb:select-none wb:focus-visible:border-ring wb:focus-visible:ring-3 wb:focus-visible:ring-ring/50 wb:active:not-aria-[haspopup]:translate-y-px wb:disabled:pointer-events-none wb:disabled:opacity-50 wb:aria-invalid:border-destructive wb:aria-invalid:ring-3 wb:aria-invalid:ring-destructive/20 wb:dark:aria-invalid:border-destructive/50 wb:dark:aria-invalid:ring-destructive/40 wb:[&_svg]:pointer-events-none wb:[&_svg]:shrink-0 wb:[&_svg:not([class*=size-])]:size-4",
  {
    variants: {
      variant: {
        default:
          "wb:bg-primary wb:text-primary-foreground wb:hover:bg-primary/80",
        outline:
          "wb:border-border wb:bg-background wb:hover:bg-muted wb:hover:text-foreground wb:aria-expanded:bg-muted wb:aria-expanded:text-foreground wb:dark:border-input wb:dark:bg-input/30 wb:dark:hover:bg-input/50",
        secondary:
          "wb:bg-secondary wb:text-secondary-foreground wb:hover:bg-[color-mix(in_oklch,var(--secondary),var(--foreground)_5%)] wb:aria-expanded:bg-secondary wb:aria-expanded:text-secondary-foreground",
        ghost:
          "wb:hover:bg-muted wb:hover:text-foreground wb:aria-expanded:bg-muted wb:aria-expanded:text-foreground wb:dark:hover:bg-muted/50",
        destructive:
          "wb:bg-destructive/10 wb:text-destructive wb:hover:bg-destructive/20 wb:focus-visible:border-destructive/40 wb:focus-visible:ring-destructive/20 wb:dark:bg-destructive/20 wb:dark:hover:bg-destructive/30 wb:dark:focus-visible:ring-destructive/40",
        link: "wb:text-primary wb:underline-offset-4 wb:hover:underline",
      },
      size: {
        default:
          "wb:h-8 wb:gap-1.5 wb:px-2.5 wb:has-data-[icon=inline-end]:pr-2 wb:has-data-[icon=inline-start]:pl-2",
        xs: "wb:h-6 wb:gap-1 wb:rounded-[min(var(--radius-md),10px)] wb:px-2 wb:text-xs wb:in-data-[slot=button-group]:rounded-lg wb:has-data-[icon=inline-end]:pr-1.5 wb:has-data-[icon=inline-start]:pl-1.5 wb:[&_svg:not([class*=size-])]:size-3",
        sm: "wb:h-7 wb:gap-1 wb:rounded-[min(var(--radius-md),12px)] wb:px-2.5 wb:text-[0.8rem] wb:in-data-[slot=button-group]:rounded-lg wb:has-data-[icon=inline-end]:pr-1.5 wb:has-data-[icon=inline-start]:pl-1.5 wb:[&_svg:not([class*=size-])]:size-3.5",
        lg: "wb:h-9 wb:gap-1.5 wb:px-2.5 wb:has-data-[icon=inline-end]:pr-2 wb:has-data-[icon=inline-start]:pl-2",
        icon: "wb:size-8",
        "icon-xs":
          "wb:size-6 wb:rounded-[min(var(--radius-md),10px)] wb:in-data-[slot=button-group]:rounded-lg wb:[&_svg:not([class*=size-])]:size-3",
        "icon-sm":
          "wb:size-7 wb:rounded-[min(var(--radius-md),12px)] wb:in-data-[slot=button-group]:rounded-lg",
        "icon-lg": "wb:size-9",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

function Button({
  className,
  variant = "default",
  size = "default",
  ...props
}: ButtonPrimitive.Props & VariantProps<typeof buttonVariants>) {
  return (
    <ButtonPrimitive
      data-slot="button"
      data-momo-ui=""
      className={cn(buttonVariants({ variant, size, className }))}
      {...props}
    />
  );
}

export { Button, buttonVariants };
