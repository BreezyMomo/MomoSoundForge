import { Separator as SeparatorPrimitive } from "@base-ui/react/separator";
import { cn } from "@/react/lib/utils";

function Separator({
  className,
  orientation = "horizontal",
  ...props
}: SeparatorPrimitive.Props) {
  return (
    <SeparatorPrimitive
      data-slot="separator"
      orientation={orientation}
      className={cn(
        "wb:shrink-0 wb:bg-border wb:data-horizontal:h-px wb:data-horizontal:w-full wb:data-vertical:w-px wb:data-vertical:self-stretch",
        className,
      )}
      {...props}
    />
  );
}

export { Separator };
